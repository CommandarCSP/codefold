money = 0
